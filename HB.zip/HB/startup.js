(function () {
    const host = document.getElementById("controlAddIn");
    if (!host) return;

    // Step 1: Load all images
    const imagePaths = [
        'HB/jinx.png',
        'HB/notog.gif',
        'HB/images/cactus_1.png',
        'HB/images/cactus_2.png',
        'HB/images/cactus_3.png',
        'HB/images/frame1.png',
        'HB/images/frame2.png',
        'HB/images/ground.png',
        'HB/images/standing.png',
        'HB/paused.png' // this one is at the root level
    ];

    const loadedImages = {};

    imagePaths.forEach((path) => {
        const img = new Image();
        const resolvedUrl = Microsoft.Dynamics.NAV.GetImageResource(path);

        if (!resolvedUrl) {
            console.error(`❌ Resource not found for: ${path}`);
            return;
        }

        img.src = resolvedUrl;
        img.onload = () => {
            console.log(`✅ Loaded: ${path}`);
            loadedImages[path] = img;
        };
        img.onerror = () => {
            console.error(`❌ Failed to load: ${path}`);
        };
    });

    // Step 2: Inject HTML
    const gifSrc = Microsoft.Dynamics.NAV.GetImageResource("HB/notog.gif");
    const jinxSrc = Microsoft.Dynamics.NAV.GetImageResource("HB/jinx.png");
    const pausedSrc = Microsoft.Dynamics.NAV.GetImageResource("paused.png");

    host.innerHTML = `
        <img src="${gifSrc}" alt="wolf" width="400" height="250" class="center">
        <div id="cats"></div>
        <div id="catCounter">0</div>
        <div id="catlerContainer">
            <button onclick="updateCats(false)">-</button>
            <img id="catler2" onclick="hideCats()" src="${jinxSrc}">
            <button onclick="updateCats(true)">+</button>
        </div>
        <input type="image" id="volume" onclick="bday()" src="${pausedSrc}">
        <input type="range" class="bruh" min="1" max="100" value="1" id="slider">
        <canvas id="game"></canvas>
    `;

    // Step 3: Signal AL that the control is ready
    Microsoft.Dynamics.NAV.InvokeExtensibilityMethod("ControlReady", []);
})();
