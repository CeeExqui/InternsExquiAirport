page 80529 HBTEST
{
    ApplicationArea = All;
    Caption = 'HB TEST';
    PageType = Card;

    layout
    {
        area(Content)
        {
            usercontrol(Control1; MyControlAddIn)
            {
                ApplicationArea = All;
            }
        }
    }
}
